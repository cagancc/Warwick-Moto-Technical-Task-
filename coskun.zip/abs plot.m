%% plot_abs_results.m
% need SLX_Coskun (simulink model)
clear; clc; close all;


abs_params;
mdl = 'SLX_Coskun';
out = sim(mdl);

% signals
t      = out.v_log.Time;
v      = out.v_log.Data(:);
w      = out.omega_log.Data(:);
s      = out.slip_log.Data(:);
Tb     = out.Tb_log.Data(:);
state  = double(out.state_log.Data(:));
tState = out.state_log.Time;

% five subplots for five signals 
fig = figure('Name', 'ABS Simulink Simulation Results', 'Position', [100 50 850 900]);

% graph 1 vehicle speed 
ax(1) = subplot(5,1,1);
plot(t, v, 'b-', 'LineWidth', 1.5); hold on;
yline(v_target, 'r--', 'Target Speed (10 m/s)');
ylabel('v [m/s]');
title('1. Vehicle Speed');
grid on;

% graph 2 wheel speed 
ax(2) = subplot(5,1,2);
plot(t, w, 'm-', 'LineWidth', 1.5); hold on;
plot(t, v / R, 'k--', 'LineWidth', 1.0);
legend('Wheel speed \omega', 'v / R (No Slip)', 'Location', 'northeast');
ylabel('\omega [rad/s]');
title('2. Wheel Speed');
grid on;

% graph 3 wheel slip 
ax(3) = subplot(5,1,3);
plot(t, 100*s, 'g-', 'LineWidth', 1.5); hold on;
yline(100*s_on, 'r--', 'ABS On (15%)');
yline(100*s_off, 'b--', 'ABS Off (10%)');
ylabel('Slip [%]');
title('3. Wheel Slip');
grid on;

% graph 4 brake torque 
ax(4) = subplot(5,1,4);
plot(t, Tb, 'k-', 'LineWidth', 1.5);
ylabel('T_b [Nm]');
title('4. Brake Torque');
grid on;

% graph 5 system state 
ax(5) = subplot(5,1,5);
stairs(tState, state, 'r-', 'LineWidth', 1.5);
yticks([0 1 2]);
yticklabels({'INACTIVE', 'BRAKING', 'ABS ACTIVE'});
ylim([-0.3 2.3]);
xlabel('Time [s]');
ylabel('State');
title('5. System State');
grid on;

% conncet time axis
linkaxes(ax, 'x');
xlim([0 max(t)]);

% save as a png 
saveas(fig, 'ABS_plots.png');
disp('GRAPHS SAVED');