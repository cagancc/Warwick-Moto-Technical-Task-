%% TS_Env.m
% torque speed envelope from the dyno data
% it has been written for the purpose of mathematically and visually deriving the motors maximum torque speed performance envelope

% i couldnt download data acqusution or communcations toolbox as i got
% errors trying to do so
% so i copied all the .tdms files shared to an ai to create .csv files 
% and used them
% code uses .tdms if it finds else .cvs
clear; clc; close all;

%% 1. settings
dataFolder = fileparts(mfilename('fullpath'));  % .tdms files sit next to this script
groupName  = '100Hz';                           % channel group inside the  files

%% 2. find the data files
files  = dir(fullfile(dataFolder, 'torque-speed-*RPM.tdms'));
if isempty(files)                               % the code searches for files matching the pattern 'torque-speed-*RPM.tdms'.
    dataFolder = uigetdir(pwd, 'Select the folder that contains the torque-speed-*RPM.tdms files');
    if isequal(dataFolder, 0)
        error('No data folder selected.');
    end
    files = dir(fullfile(dataFolder, 'torque-speed-*RPM.tdms'));
end % if no such files are found in the specified directory the user is prompted to manually select a folder
nFiles = numel(files);
if nFiles == 0
    error('No torque-speed-*RPM.tdms files found in %s', dataFolder); % if no files are found at all an error is returned
end

%% 3. maximum measured torque in each test and the RPM at which it occurred
testRPM   = zeros(nFiles, 1);   % speed the dyno was set to (from the file name for reference)
maxTorque = zeros(nFiles, 1);   % [Nm]  max of 'FMI 1'
rpm       = zeros(nFiles, 1);   % [rpm] 'EV_Measured_Speed' at the sample of maximum torque

for k = 1:nFiles
    tok        = regexp(files(k).name, '(\d+)RPM', 'tokens', 'once');
    testRPM(k) = str2double(tok{1});

    [torque, speed] = loadDyno(fullfile(dataFolder, files(k).name), groupName);

    [maxTorque(k), iMax] = max(torque);
    rpm(k)               = speed(iMax);
end

[rpm, order] = sort(rpm);              % make sure the points run from low to high speed
maxTorque    = maxTorque(order);
testRPM      = testRPM(order);

power_kW = maxTorque .* rpm * 2*pi/60 / 1000;   % mechanical power = torque x angular speed

results = table(testRPM, rpm, maxTorque, power_kW, ...
    'VariableNames', {'TestRPM', 'RPM_atMaxTorque', 'MaxTorque_Nm', 'Power_kW'});
disp(results);

%% 4. Two straight lines joined at a corner speed
% model:  T = Tc + m1*(N - Nc)                 for N <= Nc   (low speed line)
%         T = Tc + m2*(N - Nc)                 for N >  Nc   (high speed line)
% written with a "hinge" term:  T = Tc + m1*(N-Nc) + (m2-m1)*max(N-Nc, 0)
% for a given corner Nc this is linear in [Tc, m1, m2-m1] so backslash solves
% it by least squares try every corner speed in the tested range keep the best
cornerGrid = ceil(min(rpm)):1:floor(max(rpm));
bestSSE    = inf;

for Nc = cornerGrid
    X    = [ones(nFiles, 1), rpm - Nc, max(rpm - Nc, 0)];
    coef = X \ maxTorque;
    sse  = sum((X*coef - maxTorque).^2);
    if sse < bestSSE
        bestSSE  = sse;
        bestNc   = Nc;
        bestCoef = coef;
    end
end

Nc = bestNc;
Tc = bestCoef(1);
m1 = bestCoef(2);                  % slope of low-speed line   [Nm/rpm]
m2 = bestCoef(2) + bestCoef(3);    % slope of high-speed line  [Nm/rpm]
c1 = Tc - m1*Nc;                   % intercepts: T = m*N + c
c2 = Tc - m2*Nc;
rmse = sqrt(bestSSE / nFiles);

fprintf('\nCorner speed          : %.0f rpm  (torque %.1f Nm)\n', Nc, Tc);
fprintf('Low-speed line        : T = %.4f * RPM + %.2f   (%.1f Nm per 1000 rpm)\n', m1, c1, 1000*m1);
fprintf('High-speed line       : T = %.4f * RPM + %.2f   (%.1f Nm per 1000 rpm)\n', m2, c2, 1000*m2);
fprintf('Fit RMS error         : %.2f Nm\n', rmse);

%% 5. plot
figure('Name', 'Torque-speed envelope', 'Position', [100 100 800 520]);
hold on; grid on;

plot(rpm, maxTorque, 'ko', 'MarkerFaceColor', 'k', 'DisplayName', 'Max measured torque');

n1 = [min(rpm), Nc];
n2 = [Nc, max(rpm)];
plot(n1, m1*n1 + c1, 'b-', 'LineWidth', 2, ...
    'DisplayName', sprintf('Constant-torque region: T = %.4f N + %.1f', m1, c1));
plot(n2, m2*n2 + c2, 'r-', 'LineWidth', 2, ...
    'DisplayName', sprintf('Constant-power region: T = %.4f N + %.1f', m2, c2));
plot(Nc, Tc, 'gs', 'MarkerSize', 10, 'LineWidth', 2, ...
    'DisplayName', sprintf('Corner: %.0f rpm', Nc));

xlabel('Speed (RPM)');
ylabel('Maximum measured torque (Nm)');
title('Torque-speed envelope');
legend('Location', 'northeast');
xlim([0, max(rpm)*1.05]);
ylim([0, max(maxTorque)*1.15]);

saveas(gcf, fullfile(dataFolder, 'TS_Env.png'));

%% local helpers
function [torque, speed] = loadDyno(tdmsFile, groupName)
    % reads the two channels needed from a TDMS file if tdmsread is not
    % available  the CSV
    % copy next to the TDMS file is used instead the CSV holds the same
    % channels exported unchanged from the TDMS file
    try
        data   = tdmsread(tdmsFile, 'ChannelGroupName', groupName);
        tt     = data{1};                                % timetable one column per channel
        torque = getChannel(tt, 'FMI 1');
        speed  = getChannel(tt, 'EV_Measured_Speed');
    catch err
        csvFile = [tdmsFile(1:end-5) '.csv'];            % same name .csv instead of .tdms
        if ~isfile(csvFile)
            rethrow(err);
        end
        fprintf('tdmsread not available, reading %s instead\n', csvFile);
        T      = readtable(csvFile);
        torque = T.Torque_Nm;                            % 'FMI 1'
        speed  = T.Speed_rpm;                            % 'EV_Measured_Speed'
    end
end

function x = getChannel(tt, name)
    % returns a channel as a column vector matlab may rename channels such as
    % 'FMI 1' when it builds the table so compare names with spaces and
    % underscores removed and in lower case
    clean = @(s) lower(regexprep(s, '[^A-Za-z0-9]', ''));
    vn    = tt.Properties.VariableNames;
    idx   = find(strcmp(clean(vn), clean(name)), 1);
    if isempty(idx)
        error('Channel "%s" not found. Available channels: %s', name, strjoin(vn, ', '));
    end
    x = double(tt.(vn{idx}));
    x = x(:);
end